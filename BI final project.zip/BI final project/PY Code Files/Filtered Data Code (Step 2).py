import pandas as pd

# Path to the merged dataset
merged_data_path = r"C:\Users\Administrator.BH3FRC2-101448\Desktop\merged_data.csv"

# Reading the merged dataset into a pandas DataFrame
merged_data = pd.read_csv(merged_data_path)

# Converting the 'Date' column to datetime format for easier date manipulation
merged_data['Date'] = pd.to_datetime(merged_data['Date'])

# Defining the date range for filtering
start_date = pd.to_datetime("2012-01-01")
end_date = pd.to_datetime("2022-12-01")

# Filtering the data to include only records within the specified date range
filtered_data = merged_data[(merged_data['Date'] >= start_date) & (merged_data['Date'] <= end_date)]

# Saving the filtered data to a CSV file
output_path = r"C:\Users\Administrator.BH3FRC2-101448\Desktop\filtered_data.csv"
filtered_data.to_csv(output_path, index=False)

# Confirmation message for data export
print(f"Filtered data saved to {output_path}")
