import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the provided dataset for visualization
file_path = r"C:\Users\Administrator.BH3FRC2-101448\Desktop\filtered_data.csv"
data = pd.read_csv(file_path)

# Convert Date column to datetime format for better handling in plots
data['Date'] = pd.to_datetime(data['Date'])

# Set the Date column as the index for the time series plots
data.set_index('Date', inplace=True)

# Plotting various visualizations

# Visualization 1: Time Series Plot for CPI Energy
plt.figure(figsize=(12, 6))
plt.plot(data.index, data['CPIENGSL'], color='blue', label='CPI Energy')
plt.title('CPI Energy Over Time')
plt.xlabel('Date')
plt.ylabel('CPI Energy')
plt.grid(True)
plt.show()

# Visualization 2: Correlation Heatmap
plt.figure(figsize=(10, 8))
sns.heatmap(data.corr(), annot=True, cmap='coolwarm')
plt.title('Correlation Matrix of All Variables')
plt.show()

# Visualization 3: Time Series Plot for SPDR Fund Close Price
plt.figure(figsize=(12, 6))
plt.plot(data.index, data['Close'], color='red', label='SPDR Fund Close Price')
plt.title('SPDR Fund Close Price Over Time')
plt.xlabel('Date')
plt.ylabel('Close Price (USD)')
plt.grid(True)
plt.show()


# Visualization 4: Scatter Plot for CPIENGSL vs SPDR Close Price
plt.figure(figsize=(10, 6))
plt.scatter(data['CPIENGSL'], data['Close'], color='purple')
plt.title('CPI Energy vs SPDR Fund Close Price')
plt.xlabel('CPI Energy')
plt.ylabel('SPDR Fund Close Price (USD)')
plt.grid(True)
plt.show()