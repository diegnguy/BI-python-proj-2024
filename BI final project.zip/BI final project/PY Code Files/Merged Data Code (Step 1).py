import pandas as pd

# Paths to the datasets
cpi_energy_path = r"C:\Users\Administrator.BH3FRC2-101448\Desktop\CPI_energy_USA.xls"
spdr_monthly_data_path = r"C:\Users\Administrator.BH3FRC2-101448\Desktop\SPDR_found_monlty_data.csv"
electric_power_sector_path = r"C:\Users\Administrator.BH3FRC2-101448\Desktop\Electric_power_sector_1.xlsx"

# Reading the datasets into pandas DataFrames
cpi_energy = pd.read_excel(cpi_energy_path)
spdr_monthly_data = pd.read_csv(spdr_monthly_data_path)
electric_power_sector = pd.read_excel(electric_power_sector_path)

# Cleaning the CPI Energy USA Dataset
cpi_energy_cleaned = pd.read_excel(cpi_energy_path, header=10)

# Cleaning the Electric Power Sector Dataset
electric_power_sector_sample = pd.read_excel(electric_power_sector_path, header=None)
electric_power_sector_columns = electric_power_sector_sample.iloc[10, :].tolist()
electric_power_sector_cleaned = pd.read_excel(electric_power_sector_path, header=11, skiprows=range(12, 22))

# Selecting relevant columns from Electric Power Sector Dataset
electric_power_sector_cleaned = electric_power_sector_cleaned.iloc[:, [0, -1]]

# Renaming columns for clarity
electric_power_sector_cleaned.rename(columns={'Unnamed: 0': 'Date', electric_power_sector_cleaned.columns[-1]: 'Energy_Generation'}, inplace=True)
cpi_energy_cleaned.rename(columns={'observation_date': 'Date'}, inplace=True)

# Standardizing date formats across datasets
cpi_energy_cleaned['Date'] = pd.to_datetime(cpi_energy_cleaned['Date'])
electric_power_sector_cleaned['Date'] = pd.to_datetime(electric_power_sector_cleaned['Date'])
spdr_monthly_data['Date'] = pd.to_datetime(spdr_monthly_data['Date'])

# Merging datasets on the 'Date' column with an outer merge
merged_data = pd.merge(pd.merge(cpi_energy_cleaned, electric_power_sector_cleaned, on='Date', how='outer'), spdr_monthly_data, on='Date', how='outer')
merged_data.sort_values(by='Date', inplace=True)  # Sorting by date

# Saving the merged data to a CSV file
output_path = r"C:\Users\Administrator.BH3FRC2-101448\Desktop\merged_data.csv"
merged_data.to_csv(output_path, index=False)
print(f"Merged data saved to {output_path}")
